def vigenere_encrypt(text, key):
    result = ''
    key = key.lower()
    key_index = 0

    for c in text:
        if c.isalpha():
            shift = ord(key[key_index % len(key)]) - ord('a')
            base = ord('A') if c.isupper() else ord('a')
            result += chr((ord(c) - base + shift) % 26 + base)
            key_index += 1
        else:
            result += c  # keep numbers and symbols unchanged
    return result

with open("xor.txt") as f:
    plain = f.read().strip()

cipher = vigenere_encrypt(plain, "ctftest")

with open("vig.txt", "w") as f:
    f.write(cipher)

print(" Vigenère encryption complete.")
